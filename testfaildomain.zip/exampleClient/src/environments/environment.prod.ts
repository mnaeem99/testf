export const environment = {
	production: true,
	apiUrl: 'https://127.0.0.1:5555',
	};